#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 12345
#define BUFFER_SIZE 1024

void send_command(int socket, const char *command);

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    char command[BUFFER_SIZE];

    // Create a socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Define the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1"); // IP address of Smain server
    server_addr.sin_port = htons(PORT);

    // Connect to the server
    if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connect failed");
        exit(EXIT_FAILURE);
    }

    while (1) {
        printf("Enter command: ");
        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = 0;  // Remove trailing newline

        // Send the command
        send_command(client_socket, command);

        // If the command is "ufile", send the file data
        if (strncmp(command, "ufile", 5) == 0) {
            // Extract filename and folder
            char *filename = strtok(command + 6, " ");
            char *folder = strtok(NULL, " ");

            if (filename && folder) {
                printf("Trying to open file: %s\n", filename); // Debug line
                FILE *file = fopen(filename, "rb");
                if (file) {
                    char buffer[BUFFER_SIZE];
                    size_t bytes_read;
                    
                    // Send the file data
                    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
                        send(client_socket, buffer, bytes_read, 0);
                    }

                    fclose(file);
                } else {
                    perror("File open failed");
                }
            } else {
                printf("Invalid command format\n");
            }
        }
    }

    close(client_socket);
    return 0;
}

void send_command(int socket, const char *command) {
    send(socket, command, strlen(command), 0);
}
