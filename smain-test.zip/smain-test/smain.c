#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <fcntl.h>

#define PORT 12345
#define BUFFER_SIZE 1024
#define MAX_PATH_LENGTH 2048

void handle_client(int client_socket);

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    
    // Create a socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Define the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind the socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_socket, 5) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Smain server is running...\n");

    while (1) {
        // Accept a connection
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_len);
        if (client_socket < 0) {
            perror("Accept failed");
            continue;
        }

        // Fork a new process to handle the client
        if (fork() == 0) {
            close(server_socket);
            handle_client(client_socket);
            close(client_socket);
            exit(0);
        }
        close(client_socket);
    }

    close(server_socket);
    return 0;
}

void handle_client(int client_socket) {
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;

    while ((bytes_read = recv(client_socket, buffer, sizeof(buffer) - 1, 0)) > 0) {
        buffer[bytes_read] = '\0';

        // Parse the command
        char command[10];
        char filename[256];
        char destination_path[256];
        
        // Extract command and arguments
        sscanf(buffer, "%s %s %s", command, filename, destination_path);

        if (strcmp(command, "ufile") == 0) {
            // Create destination path
            char dir_path[MAX_PATH_LENGTH];
            char file_path[MAX_PATH_LENGTH];
            
            snprintf(dir_path, sizeof(dir_path), "%s", destination_path);

            // Check if filename and directory path fit in the buffers
            size_t dir_len = strlen(dir_path);
            size_t file_len = strlen(filename);

            if (dir_len + file_len + 2 > sizeof(file_path)) {
                send(client_socket, "Path or filename too long\n", 28, 0);
                continue;
            }

            int result = snprintf(file_path, sizeof(file_path), "%s/%s", dir_path, filename);

            // Check for truncation
            if (result < 0 || result >= sizeof(file_path)) {
                send(client_socket, "Path or filename too long\n", 28, 0);
                continue;
            }

            // Ensure directory exists
            struct stat st = {0};
            if (stat(dir_path, &st) == -1) {
                if (mkdir(dir_path, 0700) < 0) {
                    perror("Directory creation failed");
                    send(client_socket, "Directory creation failed\n", 27, 0);
                    continue;
                }
            }

            // Open file for writing
            int file_fd = open(file_path, O_WRONLY | O_CREAT | O_TRUNC, 0666);
            if (file_fd < 0) {
                perror("File open failed");
                send(client_socket, "File upload failed\n", 20, 0);
                continue;
            }

            // Receive file data
            ssize_t bytes_received;
            while ((bytes_received = recv(client_socket, buffer, sizeof(buffer), 0)) > 0) {
                write(file_fd, buffer, bytes_received);
            }

            close(file_fd);

            // Notify client
            send(client_socket, "File uploaded successfully\n", 28, 0);
        } 
        else if (strcmp(command, "dfile") == 0) {
            // Handle file download
            // Similar logic for downloading files from Smain or forwarding to/from Spdf/Stext
        } 
        else if (strcmp(command, "rmfile") == 0) {
            // Handle file removal
            // Implement logic to remove files locally or request removal from Spdf/Stext
        } 
        else if (strcmp(command, "dtar") == 0) {
            // Handle creating and sending tar files
        } 
        else if (strcmp(command, "display") == 0) {
            // Handle displaying file list
        } 
        else {
            // Invalid command
            send(client_socket, "Invalid command\n", 17, 0);
        }
    }

    if (bytes_read < 0) {
        perror("recv failed");
    }
}
